-- tera-setting: a single new party-submenu screen, "SET TERA," that reads
-- and writes a Pokemon's Tera Type through g9-battle-engine-beta's own
-- gigantamax/tera_state.lua API (getTeraType/setTeraType) -- this mod owns
-- zero storage of its own, purely a UI over that mod's exports, the same
-- "read/modify via someone else's API, no ownership of the value itself"
-- shape this whole project's UI screens already use.
--
-- Menu entry point: START > PARTY > select a Pokemon > SET TERA -- added
-- via mod.hooks:wrap("ui.party.submenu", ...), the exact sanctioned
-- extension point g9-battle-engine-beta's own modern_stats_screen.lua
-- already uses for its "STATS" entry, confirmed working on Gen 2 by
-- reading src/ui/gen2/PartyMenu.lua's own dispatch directly
-- ("A hook-injected entry carries a callback... answered first," calling
-- item.onSelect(mon, self.game)) -- APPENDS a new item rather than
-- replacing an existing one, so nothing about the native party menu (or
-- that mod's own entry) changes.
--
-- CONFIRMED LIVE BUG, fixed here (2026-08-20): the menu entry itself
-- displayed and was selectable, but selecting it silently killed the game
-- -- no error screen, no traceback anywhere in the log, which rules out an
-- ordinary catchable Lua error and points at something lower-level. Two
-- real, separate risks were found and both are addressed:
--   1. This hook's own table.insert was unconditional. src/ui/gen2/
--      PartyMenu.lua's own NUM_MONMENU_ITEMS (= 8) is the real ceiling
--      the native submenu box's tile rendering was built for -- native
--      code respects it explicitly (CANCEL is only appended "while the
--      list is still short of NUM_MONMENU_ITEMS," so a mon that already
--      knows enough field moves has no CANCEL row rather than exceeding
--      it). Pushing past that ceiling risks a native tile-buffer overrun,
--      not a catchable Lua error -- exactly the "no traceback" symptom.
--      Guarded here the identical way native CANCEL already is.
--   2. The original version requested a custom 256x144 UI canvas via
--      Renderer:setUISize, the same trick g9-battle-engine-beta's own
--      modern_stats_screen.lua uses -- except that file explicitly
--      DISABLES itself on a Gen 2 boot ("verified only against Gen 1
--      party mon shapes... rather than shipping it unverified"), meaning
--      that specific mechanism has never actually been proven safe on
--      Gen 2, the only game this mod (or g9-battle-engine-beta) ever
--      runs under. Removed entirely -- this screen now draws on
--      whatever canvas size is already active (the native 160x144 GB
--      surface on a real Gen 2 boot) rather than requesting a resize at
--      all, the same way the overwhelming majority of native and mod
--      screens in this codebase already do.
-- Both are real, independently-justified fixes -- which one (or both)
-- actually caused the crash is not confirmed, since a native-level
-- failure leaves no trace to read back. update()/draw() are also now
-- pcall-guarded, logging once and popping the screen on any further
-- catchable error instead of repeating it every frame.
--
-- Screen: 19 cells (18 real types + STELLAR), 16 in a 4x4 grid, the
-- remaining 3 (STEEL/FAIRY/STELLAR) on their own row underneath, in the
-- exact order battle_forms's own data/terablast.lua and TERA_CHOICES
-- already establish (Red's 15 native types, then DARK/STEEL/FAIRY) with
-- STELLAR appended 19th -- not a new ordering invented here. Each cell is
-- filled with that type's own real color (the palette every mainline game
-- itself uses) and labeled in lowercase, per explicit instruction --
-- handed to Font.draw as a literal lowercase string rather than run
-- through this engine's Strings()/romText() helpers, which exist for the
-- classic ALL-CAPS menu vocabulary. Text color per cell is chosen from the
-- fill color's own perceived brightness so every label stays readable
-- without a hand-tuned per-type exception list.
return function(mod)
  local Font = require("src.render.Font")

  -- Same order as battle_forms's own data/terablast.lua/TERA_CHOICES
  -- (confirmed by reading both directly), STELLAR appended last.
  local TYPES = {
    { id = "NORMAL",       label = "normal",   color = 0xA8A878 },
    { id = "FIGHTING",     label = "fighting", color = 0xC03028 },
    { id = "FLYING",       label = "flying",   color = 0xA890F0 },
    { id = "POISON",       label = "poison",   color = 0xA040A0 },
    { id = "GROUND",       label = "ground",   color = 0xE0C068 },
    { id = "ROCK",         label = "rock",     color = 0xB8A038 },
    { id = "BUG",          label = "bug",      color = 0xA8B820 },
    { id = "GHOST",        label = "ghost",    color = 0x705898 },
    { id = "FIRE",         label = "fire",     color = 0xF08030 },
    { id = "WATER",        label = "water",    color = 0x6890F0 },
    { id = "GRASS",        label = "grass",    color = 0x78C850 },
    { id = "ELECTRIC",     label = "electric", color = 0xF8D030 },
    { id = "PSYCHIC_TYPE", label = "psychic",  color = 0xF85888 },
    { id = "ICE",          label = "ice",      color = 0x98D8D8 },
    { id = "DRAGON",       label = "dragon",   color = 0x7038F8 },
    { id = "DARK",         label = "dark",     color = 0x705848 },
    { id = "STEEL",        label = "steel",    color = 0xB8B8D0 },
    { id = "FAIRY",        label = "fairy",    color = 0xEE99AC },
    { id = "STELLAR",      label = "stellar",  color = 0x40B5A5 },
  }

  -- Native GB surface (160x144) -- no Renderer:setUISize call, no custom
  -- canvas at all. See file header for why that trick was removed.
  local UI_W, UI_H = 160, 144
  local COLS = 4
  local HEADER_H = 16
  local CELL_W = UI_W / COLS -- 40
  local CELL_H = (UI_H - HEADER_H) / 5 -- 25.6, 5 rows (4 full + the 3-cell remainder row)

  -- Plain arithmetic, not Lua 5.3's >>/& operators -- LOVE2D runs on
  -- LuaJIT (Lua 5.1 semantics), which does not have them natively.
  local function hexColor(hex)
    local r = math.floor(hex / 65536) % 256 / 255
    local g = math.floor(hex / 256) % 256 / 255
    local b = hex % 256 / 255
    return r, g, b
  end

  -- Perceived-brightness threshold (the standard NTSC luma weights) --
  -- picks readable text color per cell from its own fill rather than a
  -- hand-maintained light/dark list for all 19 types.
  local function readableTextColor(hex)
    local r, g, b = hexColor(hex)
    local luma = 0.299 * r + 0.587 * g + 0.114 * b
    if luma > 0.6 then return 0, 0, 0 end
    return 1, 1, 1
  end

  -- One shared scale for every cell, sized to whatever "fighting" (the
  -- widest label in the grid) needs to fit -- explicit instruction after
  -- a live screenshot showed short labels ("rock," "bug," "dark")
  -- rendering visibly larger than long ones, since each cell was
  -- previously computing its own independent shrink-to-fit scale.
  -- Computed lazily (Font isn't guaranteed loaded until the mod's own
  -- install runs) and cached, not recomputed every frame.
  local uniformScale = nil
  local function labelScale()
    if uniformScale then return uniformScale end
    local padding = 4
    local available = CELL_W - padding
    local widestW = Font.width and Font.width("fighting") or (#"fighting" * 6)
    uniformScale = math.min(1.0, available / math.max(1, widestW))
    return uniformScale
  end

  local function cellRect(index)
    local i = index - 1
    local row = math.floor(i / COLS)
    local col = i % COLS
    return col * CELL_W, HEADER_H + row * CELL_H, CELL_W, CELL_H
  end

  local Screen = {}
  Screen.__index = Screen
  Screen.isOpaque = true
  Screen.screenId = "TeraSettingGrid"

  function Screen.new(game, mon)
    local g9 = mod.find and mod.find("g9-battle-engine-beta")
    local api = g9 and g9.exports
    local self = setmetatable({
      game = game, mon = mon, api = api,
      cursor = 1, broken = false,
    }, Screen)
    self:syncCursorToCurrent()
    return self
  end

  function Screen:currentType()
    if not (self.api and self.api.getTeraType) then return nil end
    local ok, value = pcall(self.api.getTeraType, self.mon, nil)
    return ok and value or nil
  end

  function Screen:syncCursorToCurrent()
    local current = self:currentType()
    if not current then return end
    for i, t in ipairs(TYPES) do
      if t.id == current then
        self.cursor = i
        return
      end
    end
  end

  function Screen:moveCursor(dx, dy)
    local i = self.cursor - 1
    local row = math.floor(i / COLS)
    local col = i % COLS

    if dx ~= 0 then
      local rowCount = (row == 4) and 3 or COLS -- the last row only holds 3 cells
      col = col + dx
      if col < 0 then col = rowCount - 1 end
      if col >= rowCount then col = 0 end
    end

    if dy ~= 0 then
      row = row + dy
      if row < 0 then row = 4 end
      if row > 4 then row = 0 end
      local rowCount = (row == 4) and 3 or COLS
      if col >= rowCount then col = rowCount - 1 end
    end

    local newIndex = row * COLS + col + 1
    if newIndex >= 1 and newIndex <= #TYPES then
      self.cursor = newIndex
    end
  end

  local function safeCall(self, label, fn)
    local ok, err = pcall(fn)
    if not ok then
      mod.log:warn("tera-setting: %s errored, closing the screen (%s)", label, tostring(err))
      self.broken = true
    end
  end

  function Screen:update(dt)
    if self.broken then
      if self.game and self.game.stack then self.game.stack:pop() end
      return
    end
    safeCall(self, "update", function()
      local input = self.game.input
      if input:wasPressed("left") then self:moveCursor(-1, 0) return end
      if input:wasPressed("right") then self:moveCursor(1, 0) return end
      if input:wasPressed("up") then self:moveCursor(0, -1) return end
      if input:wasPressed("down") then self:moveCursor(0, 1) return end
      if input:wasPressed("a") then
        local picked = TYPES[self.cursor]
        if picked and self.api and self.api.setTeraType then
          pcall(self.api.setTeraType, self.mon, picked.id, nil)
        end
        self.game.stack:pop()
        return
      end
      if input:wasPressed("b") then
        self.game.stack:pop()
      end
    end)
  end

  function Screen:draw()
    if self.broken then return end
    safeCall(self, "draw", function()
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.rectangle("fill", 0, 0, UI_W, UI_H)

      local current = self:currentType()
      local currentLabel = "----"
      for _, t in ipairs(TYPES) do
        if t.id == current then currentLabel = t.label break end
      end
      love.graphics.setColor(0, 0, 0, 1)
      do
        local text = "Tera: " .. currentLabel
        local headerAvailable = UI_W - 8
        local headerW = Font.width and Font.width(text) or (#text * 6)
        local headerScale = math.min(1.0, headerAvailable / math.max(1, headerW))
        love.graphics.push()
        love.graphics.translate(4, 2)
        love.graphics.scale(headerScale, headerScale)
        Font.draw(text, 0, 0)
        love.graphics.pop()
      end

      for i, t in ipairs(TYPES) do
        local x, y, w, h = cellRect(i)
        local r, g, b = hexColor(t.color)
        love.graphics.setColor(r, g, b, 1)
        love.graphics.rectangle("fill", x + 1, y + 1, w - 2, h - 2)

        if i == self.cursor then
          love.graphics.setColor(0, 0, 0, 1)
          love.graphics.setLineWidth(2)
          -- love.graphics's "line" rectangle straddles the path, half the
          -- line width to either side -- inset by 1 (half of 2px) so the
          -- drawn frame sits fully inside the cell rather than bleeding a
          -- pixel into its neighbor.
          love.graphics.rectangle("line", x + 2, y + 2, w - 4, h - 4)
          love.graphics.setLineWidth(1)
        end

        local tr, tg, tb = readableTextColor(t.color)
        love.graphics.setColor(tr, tg, tb, 1)
        -- Shrink-to-fit, the identical push/translate/scale/pop technique
        -- main.lua's own installMoveNameDisplay uses for overflowing move
        -- names (Font.draw/Font.drawCode take no scale parameter) -- but
        -- one SHARED scale (labelScale(), sized to "fighting") rather than
        -- a per-label one, so every cell reads at the same size instead of
        -- short words rendering visibly larger than long ones.
        local scale = labelScale()
        local labelW = Font.width and Font.width(t.label) or (#t.label * 6)
        local drawnW = labelW * scale
        love.graphics.push()
        love.graphics.translate(x + math.floor((w - drawnW) / 2), y + math.floor(h / 2) - 4 * scale)
        love.graphics.scale(scale, scale)
        Font.draw(t.label, 0, 0)
        love.graphics.pop()
      end

      love.graphics.setColor(1, 1, 1, 1)
    end)
  end

  -- src/ui/gen2/PartyMenu.lua's own NUM_MONMENU_ITEMS (= 8, confirmed by
  -- reading it directly): the real ceiling the native submenu box's own
  -- tile rendering was built for. See file header for why this guard
  -- exists -- the identical one native CANCEL already uses.
  local NUM_MONMENU_ITEMS = 8

  mod.hooks:wrap("ui.party.submenu", function(nextFn, game, items, mon, ctx)
    local result = nextFn(game, items, mon, ctx)
    if type(result) ~= "table" then result = items end
    -- Party screen only -- never inside a battle's own switch-in submenu,
    -- the same guard modern_stats_screen.lua's own "STATS" entry uses
    -- (ctx.battle present there means the submenu opened mid-battle).
    if not (ctx and ctx.battle) and #result < NUM_MONMENU_ITEMS then
      table.insert(result, {
        label = "SET TERA",
        onSelect = function(selectedMon, selectedGame)
          local ok, screen = pcall(Screen.new, selectedGame, selectedMon)
          if ok and screen then
            selectedGame.stack:push(screen)
          else
            mod.log:warn("tera-setting: Screen.new errored, not opening (%s)", tostring(screen))
          end
        end,
      })
    end
    return result
  end, 0)

  mod.log:info("tera-setting: SET TERA party menu screen installed (19-cell type grid)")
end
